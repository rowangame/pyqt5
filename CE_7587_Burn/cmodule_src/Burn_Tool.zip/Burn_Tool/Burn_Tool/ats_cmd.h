#ifndef _ATS_CMD_H
#define _ATS_CMD_H

#include <windows.h>
#include <stdint.h>
#include <string>

#define TL_ATS_IN			"TL_ATS_IN"
#define TL_ATS_OFF			"TL_ATS_OFF"
#define TL_DFU_IN			"TL_DFU_IN"
#define TL_FAC_RST			"TL_FAC_RST"
#define TL_FAC_RST_OFF		"TL_FAC_RST_OFF"
#define TL_REBOOT			"TL_REBOOT"
#define TL_PWR_OFF			"TL_PWR_OFF"
#define TL_GET_VER			"TL_GET_VER"
#define TL_GET_BTNAME		"TL_GET_BTNAME"
#define TL_GET_BTMAC		"TL_GET_BTMAC"
#define TL_SET_DEF_EQ		"TL_SET_DEF_EQ"
#define TL_GET_DEF_EQ		"TL_GET_DEF_EQ"
#define TL_SET_DEMO_MOD		"TL_SET_DEMO_MOD"
#define TL_GET_DEMO_MOD		"TL_GET_DEMO_MOD"
#define TL_SET_COL_VAR		"TL_SET_COL_VAR"
#define TL_GET_COL_VAR		"TL_GET_COL_VAR"
#define TL_GET_MODEL		"TL_GET_MODEL"
#define TL_SET_DSN			"TL_SET_DSN"
#define TL_GET_DSN			"TL_GET_DSN"
#define TL_SET_VOL			"TL_SET_VOL"
#define TL_GET_VOL			"TL_GET_VOL"
#define TL_SPK_CTRL			"TL_SPK_CTRL"
#define TL_AC_STAT			"TL_AC_STAT"
#define TL_GET_BAT_LEVEL	"TL_GET_BAT_LEVEL"
#define TL_GET_NTC_TEMP		"TL_GET_NTC_TEMP"
#define TL_GET_CHG_CURR		"TL_GET_CHG_CURR"
#define TL_KEY_IN			"TL_KEY_IN"
#define TL_KEY_OFF			"TL_KEY_OFF"
#define TL_RGB_RED			"TL_RGB_RED"
#define TL_RGB_GREEN		"TL_RGB_GREEN"
#define TL_RGB_BLUE			"TL_RGB_BLUE"
#define TL_RGB_ALL_ON		"TL_RGB_ALL_ON"
#define TL_RGB_ALL_OFF		"TL_RGB_ALL_OFF"
#define TL_LIGHTING_RED		"TL_LIGHTING_RED"
#define TL_LIGHTING_GREEN	"TL_LIGHTING_GREEN"
#define TL_LIGHTING_BLUE	"TL_LIGHTING_BLUE"
#define TL_LIGHTING_ALL_ON	"TL_LIGHTING_ALL_ON"
#define TL_LIGHTING_ALL_OFF	"TL_LIGHTING_ALL_OFF"
#define TL_CPIC_STAT		"TL_CPIC_STAT"

#define STR_FAIL		"FAIL"
#define STR_SUCCESS		"SUCCESS"
#define STR_VER			"VER"
#define STR_BTNAME		"BTNAME"
#define STR_BTMAC		"BTMAC"
#define STR_DEF_EQ		"DEF_EQ"
#define STR_DEMO_MOD	"DEMO_MOD"
#define STR_COL_VAR		"COL_VAR"
#define STR_MODEL		"MODEL"
#define STR_DSN			"DSN"
#define STR_VOL			"VOL"
#define STR_ON			"ON"
#define STR_NG			"NG"
#define STR_BAT_LEVEL	"BAT_LEVEL"
#define STR_NTC_TEMP	"NTC_TEMP"
#define STR_CURR		"CURR"
#define STR_MA			"mA"

/* Speaker Control
 * bit 0: Left channel
 * bit 1: Right channel
 * bit 2: Woofer, (XG7 Only)
 */
#define SPK_ALL_ON		"000F"
#define SPK_ALL_OFF		"0000"
#define SPK_LEFT		"0001"
#define SPK_RIGHT		"0002"
#define SPK_WOOFER		"0004"

/* Default EQ
 * 00: SoundBoost; 01: Standard; 10: AI Sound; 11: Reserved
 */
#define EQ_SOUNDBOOST	"00"
#define EQ_STANDARD		"01"
#define EQ_AISOUND		"10"

/* Color Variation
 * 0000: BK(Black), 0001: BL(Blue), 0010: GR(Gray),
 * 0011: RE(Red), 0100: PK(Pink/Coral Haze),
 * 0101: GN(Green), 0110: YL(Yellow), 0111: BE(Beige),
 * 1000: WH(White)
 */
#define COR_BK		"0000"
#define COR_BL		"0001"
#define COR_GR		"0010"
#define COR_RD		"0011"
#define COR_PK		"0100"
#define COR_GN		"0101"
#define COR_YL		"0110"
#define COR_BE		"0111"
#define COR_WH		"1000"

#endif /* _ATS_CMD_H */